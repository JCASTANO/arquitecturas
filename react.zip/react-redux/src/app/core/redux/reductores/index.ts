import { combineReducers } from 'redux';
import productos from './productos/productosReductor';

export default combineReducers({ productos });
