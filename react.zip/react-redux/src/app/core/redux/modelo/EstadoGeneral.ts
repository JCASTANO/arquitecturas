import { EstadoProducto } from './EstadoProducto';

export interface EstadoGeneral {
  productos: EstadoProducto;
}
