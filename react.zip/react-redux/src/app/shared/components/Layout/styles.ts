import styled from 'styled-components';

export const DivContainer = styled.div`
  padding-top: 20px;
  padding-left: 16px;
  padding-right: 16px;
`;
