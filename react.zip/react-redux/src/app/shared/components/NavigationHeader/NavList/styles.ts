import styled from 'styled-components';

export const NavListUl = styled.ul`
  display: flex;
`;
