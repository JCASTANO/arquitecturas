export interface Producto {
  title: string;
  slug: string;
  body: string;
  createdAt: string;
  updatedAt: string;
}
