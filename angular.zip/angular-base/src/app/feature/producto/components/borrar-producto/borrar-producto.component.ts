import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-borrar-producto',
  templateUrl: './borrar-producto.component.html',
  styleUrls: ['./borrar-producto.component.css']
})
export class BorrarProductoComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
