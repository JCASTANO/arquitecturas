export const environment = {
  production: true,
  endpoint: '/prospectos-vida'
};