export enum NodeEnv {
  DEVELOPMENT='development',
  PRODUCTION='production',
}
